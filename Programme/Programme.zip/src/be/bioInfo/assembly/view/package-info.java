/**
  * This package contains classes for displaying the board. 
  * 
  * @author Watillon Thibaut & Opsommer Sophie, 2015
  *
  */
package be.bioInfo.assembly.view;