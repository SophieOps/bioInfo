/**
  * This package contains classes for calculating the output.
  * 
  * @author Watillon Thibaut & Opsommer Sophie, 2015
  */
package be.bioInfo.assembly.algorithm;