/**
  * This package contains classes to manage the various exceptions 
  * that may be encountered.
  * 
  * @author Watillon Thibaut & Opsommer Sophie, 2015
  *
  */
package be.bioInfo.assembly.exception;