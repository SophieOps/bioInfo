package be.bioInfo.assembly.exception;

/**
  * @author Watillon Thibaut & Opsommer Sophie, 2015
 *
 */
public class FragmentException extends Exception
{
	/**
	 * @param message
	 */
	public FragmentException(String message)
	{
		super(message);
	}

}
