package be.bioInfo.assembly.exception;

/**
  * @author Watillon Thibaut & Opsommer Sophie, 2015
 *
 */
public class GreedyException extends Exception
{
	/**
	 * @param message
	 */
	public GreedyException(String message)
	{
		super(message);
	}

}
