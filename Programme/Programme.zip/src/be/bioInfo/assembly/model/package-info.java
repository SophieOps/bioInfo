/**
  * This package contains classes that stored informations about the 
  * different objects needed
  * 
  * @author Watillon Thibaut & Opsommer Sophie, 2015
  *
  */
package be.bioInfo.assembly.model;